package executavel;

import view.Menu;

public class Executavel {

	public static void main(String[] args) {
		
		Menu menu = new Menu();
		menu.apresentarMenu();
		
	}

}
