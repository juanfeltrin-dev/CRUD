package view;

public class MenuAvisoCoordenacao {

}
