package view;

public class MenuAvisoEstagio {

}
