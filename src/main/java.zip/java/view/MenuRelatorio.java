package view;

public class MenuRelatorio {

	public void apresentarMenuRelatorio() {
		// TODO Auto-generated method stub
		
	}

}
