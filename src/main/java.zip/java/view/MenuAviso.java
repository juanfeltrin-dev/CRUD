package view;

public class MenuAviso {

	public void apresentarMenuAviso() {
		// TODO Auto-generated method stub
		
	}

}
