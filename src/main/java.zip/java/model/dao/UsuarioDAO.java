package model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.vo.UsuarioVO;

public class UsuarioDAO {

	public boolean existeRegistroPorCpfDAO(String cpf) {
		Connection conn = Banco.getConnection();
		Statement stmt = Banco.getStatement(conn);
		ResultSet resultado = null;
		String query = "select cpf from usuario where cpf = '" + cpf + "'";
		
		try {
			resultado = stmt.executeQuery(query);
			if(resultado.next()) {
				return true;
			}
		} catch (SQLException e) {
			System.out.println("Erro ao executar a query que verifica  existência de usuário por CPF");
			System.out.println("Erro: " + e.getMessage());
			return false;
		} finally {
			Banco.closeResultSet(resultado);
			Banco.closeStatement(stmt);
			Banco.closeConnection(conn);
		}
		return false;
	}

	public int cadastrarUsuarioDAO(UsuarioVO usuarioVO) {
		return 0;
	}

	public ArrayList<UsuarioVO> consultarTodosUsuariosDAO() {
		// TODO Auto-generated method stub
		return null;
	}

	public UsuarioVO consultarUsuarioDAO(UsuarioVO usuarioVO) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean existeRegistroPorIdUsuarioDAO(int idUsuario) {
		// TODO Auto-generated method stub
		return false;
	}

	public int atualizarUsuarioDAO(UsuarioVO usuarioVO) {
		// TODO Auto-generated method stub
		return 0;
	}

}
